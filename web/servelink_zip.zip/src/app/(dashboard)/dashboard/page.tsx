'use client';

import { useEffect, useState } from 'react';
import { UserRole } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, ShieldAlert, CheckCircle2, Clock, Users, FolderKanban, Building2 } from 'lucide-react';
import Link from 'next/link';

export default function DashboardPage() {
  const [role, setRole] = useState<UserRole>('NGO_ADMIN');

  useEffect(() => {
    const savedRole = localStorage.getItem('user_role') as UserRole;
    if (savedRole) setRole(savedRole);
  }, []);

  return (
    <div className="space-y-6">
      {/* Dynamic Role Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            {role === 'SUPER_ADMIN' && 'Platform Governance Dashboard'}
            {role === 'NGO_ADMIN' && 'NGO Overview Dashboard'}
            {role === 'COORDINATOR' && 'Field Operations Dashboard'}
            {role === 'VOLUNTEER' && 'My Volunteering Portal'}
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            {role === 'SUPER_ADMIN' && 'System-wide compliance, NGO verifications, and platform stats.'}
            {role === 'NGO_ADMIN' && 'Manage organization initiatives, staff, and project lifecycles.'}
            {role === 'COORDINATOR' && 'Track project tasks, volunteer assignments, and deliverables.'}
            {role === 'VOLUNTEER' && 'Track your active task assignments and completion progress.'}
          </p>
        </div>

        {/* Role Actions */}
        {role === 'NGO_ADMIN' && (
          <Link href="/projects">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
              <Plus className="h-4 w-4" /> New Project
            </Button>
          </Link>
        )}
        {role === 'COORDINATOR' && (
          <Link href="/tasks">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
              <Plus className="h-4 w-4" /> Assign New Task
            </Button>
          </Link>
        )}
        {role === 'SUPER_ADMIN' && (
          <Link href="/admin/ngos">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
              <ShieldAlert className="h-4 w-4" /> Review Pending NGOs
            </Button>
          </Link>
        )}
      </div>

      {/* Role Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {role === 'SUPER_ADMIN' && (
          <>
            <MetricCard title="Total Registered NGOs" value="12" subtext="3 Pending Verification" icon={Building2} />
            <MetricCard title="Active Volunteers" value="480" subtext="Across 8 regions" icon={Users} />
            <MetricCard title="Total Projects" value="24" subtext="18 Active" icon={FolderKanban} />
            <MetricCard title="Platform Health" value="99.9%" subtext="All systems operational" icon={CheckCircle2} />
          </>
        )}

        {role === 'NGO_ADMIN' && (
          <>
            <MetricCard title="Active Projects" value="1" subtext="Out of 2 total" icon={FolderKanban} />
            <MetricCard title="Open Tasks" value="2" subtext="Requires completion" icon={Clock} />
            <MetricCard title="Active Volunteers" value="142" subtext="Assigned to initiatives" icon={Users} />
            <MetricCard title="NGO Status" value="Verified" subtext="Compliance approved" icon={CheckCircle2} />
          </>
        )}

        {role === 'COORDINATOR' && (
          <>
            <MetricCard title="My Managed Projects" value="2" subtext="Healthcare & Education" icon={FolderKanban} />
            <MetricCard title="Pending Deliverables" value="5" subtext="2 High Priority" icon={Clock} />
            <MetricCard title="Assigned Volunteers" value="18" subtext="4 Active today" icon={Users} />
            <MetricCard title="Task Completion Rate" value="84%" subtext="+5% from last week" icon={CheckCircle2} />
          </>
        )}

        {role === 'VOLUNTEER' && (
          <>
            <MetricCard title="My Assigned Tasks" value="2" subtext="1 In Progress" icon={Clock} />
            <MetricCard title="Completed Tasks" value="8" subtext="Total deliverables done" icon={CheckCircle2} />
            <MetricCard title="Hours Contributed" value="32 hrs" subtext="This month" icon={Users} />
            <MetricCard title="Active NGO" value="Hope Foundation" subtext="Verified Member" icon={Building2} />
          </>
        )}
      </div>

      {/* Activity Section */}
      <Card className="border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-bold">
            {role === 'VOLUNTEER' ? 'My Current Deliverables' : 'Recent Activity Overview'}
          </CardTitle>
          <CardDescription className="text-xs">
            Live overview generated for role: <Badge variant="outline">{role}</Badge>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="p-3 border rounded-lg bg-gray-50 flex items-center justify-between">
            <div>
              <p className="font-semibold text-sm text-gray-900">Distribute clean water kits in Sector 4</p>
              <p className="text-xs text-gray-500">Assigned to: Priya Verma • Priority: High</p>
            </div>
            <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">IN_PROGRESS</Badge>
          </div>
          <div className="p-3 border rounded-lg bg-gray-50 flex items-center justify-between">
            <div>
              <p className="font-semibold text-sm text-gray-900">Verify volunteer registration details</p>
              <p className="text-xs text-gray-500">Assigned to: Rohan Mehta • Priority: Medium</p>
            </div>
            <Badge className="bg-blue-100 text-blue-800 border-blue-200">PENDING</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function MetricCard({ title, value, subtext, icon: Icon }: { title: string; value: string; subtext: string; icon: any }) {
  return (
    <Card className="border-gray-200">
      <CardContent className="p-4 flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
          <p className="text-xs text-gray-400 mt-1">{subtext}</p>
        </div>
        <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
          <Icon className="h-5 w-5" />
        </div>
      </CardContent>
    </Card>
  );
}