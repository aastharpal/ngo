'use client';

import { useState, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { NAV_ITEMS } from '@/config/navigation';
import { UserRole } from '@/types';
import { Building2, LogOut, LayoutDashboard } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [role, setRole] = useState<UserRole | null>(null);
  const [userEmail, setUserEmail] = useState<string>('user@servelink.org');

  useEffect(() => {
    const savedRole = localStorage.getItem('user_role') as UserRole;
    const savedEmail = localStorage.getItem('user_email');

    if (!savedRole) {
      router.push('/login');
      return;
    }

    setRole(savedRole);
    if (savedEmail) setUserEmail(savedEmail);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('user_role');
    localStorage.removeItem('user_email');
    router.push('/login');
  };

  if (!role) {
    return null;
  }

  const allowedNavItems = NAV_ITEMS.filter((item) => item.roles.includes(role));

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col justify-between p-4 sticky top-0 h-screen">
        <div className="space-y-6">
          {/* Logo */}
          <div className="flex items-center gap-2 px-2">
            <div className="p-2 bg-blue-600 text-white rounded-lg">
              <Building2 className="h-6 w-6" />
            </div>
            <span className="text-xl font-bold text-gray-900 tracking-tight">ServeLink</span>
          </div>

          {/* Dynamic Navigation Links */}
          <nav className="space-y-1">
            {allowedNavItems.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 font-semibold'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                  }`}
                >
                  <LayoutDashboard className="h-4 w-4" />
                  <span>{item.title}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* User Profile & Logout */}
        <div className="border-t border-gray-100 pt-4 flex items-center justify-between">
          <div className="flex items-center gap-2 overflow-hidden">
            <div className="h-8 w-8 rounded-full bg-gray-900 text-white flex items-center justify-center font-bold text-xs shrink-0">
              {role.charAt(0)}
            </div>
            <div className="truncate text-xs">
              <p className="font-semibold text-gray-900 truncate">{userEmail}</p>
              <p className="text-gray-500 font-mono text-[10px] uppercase">{role}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLogout}
            title="Log Out"
            className="text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg shrink-0"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col">
        <header className="h-14 border-b border-gray-200 bg-white px-6 flex items-center justify-between text-xs text-gray-600">
          <div>
            Role Context: <span className="font-bold text-gray-900">{role}</span>
          </div>
        </header>

        <div className="p-8 flex-1">{children}</div>
      </main>
    </div>
  );
}