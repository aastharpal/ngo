'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Building2, Shield, User, UserCheck, ArrowRight } from 'lucide-react';
import { UserRole } from '@/types';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('admin@hopefoundation.org');
  const [password, setPassword] = useState('••••••••');
  const [selectedRole, setSelectedRole] = useState<UserRole>('NGO_ADMIN');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('user_role', selectedRole);
    localStorage.setItem('user_email', email);
    router.push('/dashboard');
  };

  const quickRoles: { role: UserRole; label: string; email: string; icon: any }[] = [
    { role: 'SUPER_ADMIN', label: 'Super Admin', email: 'admin@servelink.org', icon: Shield },
    { role: 'NGO_ADMIN', label: 'NGO Admin', email: 'admin@hopefoundation.org', icon: Building2 },
    { role: 'COORDINATOR', label: 'Coordinator', email: 'coordinator@hopefoundation.org', icon: UserCheck },
    { role: 'VOLUNTEER', label: 'Volunteer', email: 'priya@example.com', icon: User },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-lg space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center p-3 bg-blue-600 rounded-xl text-white shadow-lg mb-2">
            <Building2 className="h-8 w-8" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900">Sign in to ServeLink</h1>
          <p className="text-sm text-gray-500">Select a demo role or enter your credentials</p>
        </div>

        {/* Quick Role Switcher Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {quickRoles.map((item) => {
            const Icon = item.icon;
            const isSelected = selectedRole === item.role;
            return (
              <button
                key={item.role}
                type="button"
                onClick={() => {
                  setSelectedRole(item.role);
                  setEmail(item.email);
                }}
                className={`p-2.5 rounded-lg border text-left transition-all flex flex-col items-center gap-1 ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/50 text-blue-700 ring-1 ring-blue-600'
                    : 'border-gray-200 bg-white text-gray-600 hover:border-gray-300'
                }`}
              >
                <Icon className={`h-4 w-4 ${isSelected ? 'text-blue-600' : 'text-gray-400'}`} />
                <span className="text-xs font-semibold text-center">{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Login Form */}
        <Card className="border-gray-200 shadow-sm">
          <form onSubmit={handleLogin}>
            <CardHeader className="space-y-1 pb-4">
              <CardTitle className="text-lg font-bold">Account Credentials</CardTitle>
              <CardDescription className="text-xs">
                Active role context: <Badge variant="outline" className="font-semibold text-blue-600 ml-1">{selectedRole}</Badge>
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs font-medium">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@organization.org"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="password" className="text-xs font-medium">Password</Label>
                <Input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </CardContent>

            <CardFooter>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white gap-2">
                Sign In
                <ArrowRight className="h-4 w-4" />
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
}