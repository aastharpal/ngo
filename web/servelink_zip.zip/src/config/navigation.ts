export interface NavItem {
  title: string;
  href: string;
  roles: string[];
}

export const NAV_ITEMS: NavItem[] = [
  {
    title: 'Dashboard',
    href: '/dashboard',
    roles: ['SUPER_ADMIN', 'NGO_ADMIN', 'COORDINATOR', 'VOLUNTEER'],
  },
  {
    title: 'NGO Verification',
    href: '/admin/ngos',
    roles: ['SUPER_ADMIN'],
  },
  {
    title: 'Projects',
    href: '/projects',
    roles: ['NGO_ADMIN', 'COORDINATOR', 'VOLUNTEER'],
  },
  {
    title: 'My Tasks',
    href: '/tasks',
    roles: ['NGO_ADMIN', 'COORDINATOR', 'VOLUNTEER'],
  },
  {
    title: 'Invitations',
    href: '/invitations',
    roles: ['NGO_ADMIN', 'COORDINATOR'],
  },
  {
    title: 'NGO Profile',
    href: '/ngo/profile',
    roles: ['NGO_ADMIN', 'COORDINATOR'],
  },
];