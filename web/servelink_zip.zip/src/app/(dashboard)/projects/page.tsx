'use client';

import { useState } from 'react';
import { MOCK_PROJECTS } from '@/lib/mock-data';
import { Project, ProjectStatus } from '@/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { FolderKanban, Plus, MapPin, Calendar, Users, Wrench } from 'lucide-react';

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>(MOCK_PROJECTS);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Healthcare');
  const [location, setLocation] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [requiredVolunteers, setRequiredVolunteers] = useState('10');
  const [skillsInput, setSkillsInput] = useState('');

  // Handle New Project Submission
  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();

    const newProject: Project = {
      id: `prj-${Date.now()}`,
      ngoId: 'ngo-101',
      title,
      description,
      category,
      location,
      startDate,
      endDate,
      requiredVolunteers: parseInt(requiredVolunteers, 10) || 1,
      requiredSkills: skillsInput.split(',').map((s) => s.trim()).filter(Boolean),
      status: 'PLANNED',
      createdBy: 'usr-2',
      createdAt: new Date().toISOString(),
    };

    setProjects([newProject, ...projects]);
    setIsDialogOpen(false);

    // Reset Form
    setTitle('');
    setDescription('');
    setLocation('');
    setStartDate('');
    setEndDate('');
    setSkillsInput('');
  };

  const getStatusBadge = (status: ProjectStatus) => {
    switch (status) {
      case 'ACTIVE':
        return <Badge className="bg-green-100 text-green-800 border-green-200">Active</Badge>;
      case 'PLANNED':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Planned</Badge>;
      case 'COMPLETED':
        return <Badge className="bg-gray-100 text-gray-800 border-gray-200">Completed</Badge>;
      case 'CANCELLED':
        return <Badge className="bg-red-100 text-red-800 border-red-200">Cancelled</Badge>;
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header with Action Button */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 flex items-center gap-2">
            <FolderKanban className="h-7 w-7 text-blue-600" />
            Projects Management
          </h1>
          <p className="text-gray-500 text-sm mt-1">
            Create initiatives, allocate volunteer roles, and track project timelines.
          </p>
        </div>
        <Button
          onClick={() => setIsDialogOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white gap-2 self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          New Project
        </Button>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <Card key={project.id} className="border-gray-200 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <Badge variant="outline" className="text-xs font-semibold text-blue-600 bg-blue-50 border-blue-200">
                  {project.category}
                </Badge>
                {getStatusBadge(project.status)}
              </div>
              <CardTitle className="text-lg font-bold text-gray-900 mt-2 line-clamp-1">
                {project.title}
              </CardTitle>
              <CardDescription className="text-xs text-gray-500 line-clamp-2 mt-1">
                {project.description}
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-3 text-xs text-gray-600 py-2 border-t border-b border-gray-100 my-2">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-gray-400 shrink-0" />
                <span className="truncate">{project.location}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-gray-400 shrink-0" />
                <span>{project.startDate} to {project.endDate}</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-gray-400 shrink-0" />
                <span>{project.requiredVolunteers} Volunteers Required</span>
              </div>
              <div className="flex items-start gap-2 pt-1">
                <Wrench className="h-4 w-4 text-gray-400 shrink-0 mt-0.5" />
                <div className="flex flex-wrap gap-1">
                  {project.requiredSkills.map((skill) => (
                    <span key={skill} className="px-1.5 py-0.5 bg-gray-100 rounded text-[10px] font-medium text-gray-700">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </CardContent>

            <CardFooter className="pt-3">
              <Button variant="outline" className="w-full text-xs h-9">
                Manage Tasks & Team
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {/* Create Project Modal */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold text-gray-900">Create New Project</DialogTitle>
            <DialogDescription className="text-sm text-gray-500">
              Fill in the project details below to list it for volunteers and coordinators.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreateProject} className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="title" className="text-xs font-medium">Project Title</Label>
              <Input
                id="title"
                required
                placeholder="e.g., Clean Water Relief Drive"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="description" className="text-xs font-medium">Description</Label>
              <Input
                id="description"
                required
                placeholder="Brief summary of goals and activities"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="category" className="text-xs font-medium">Category</Label>
                <Input
                  id="category"
                  required
                  placeholder="e.g., Healthcare, Education"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="location" className="text-xs font-medium">Location</Label>
                <Input
                  id="location"
                  required
                  placeholder="City or Village name"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="startDate" className="text-xs font-medium">Start Date</Label>
                <Input
                  id="startDate"
                  type="date"
                  required
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="endDate" className="text-xs font-medium">End Date</Label>
                <Input
                  id="endDate"
                  type="date"
                  required
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="volunteers" className="text-xs font-medium">Required Volunteers</Label>
                <Input
                  id="volunteers"
                  type="number"
                  min="1"
                  required
                  value={requiredVolunteers}
                  onChange={(e) => setRequiredVolunteers(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="skills" className="text-xs font-medium">Skills (Comma Separated)</Label>
                <Input
                  id="skills"
                  placeholder="Logistics, First Aid, Teaching"
                  value={skillsInput}
                  onChange={(e) => setSkillsInput(e.target.value)}
                />
              </div>
            </div>

            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white">
                Create Project
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}