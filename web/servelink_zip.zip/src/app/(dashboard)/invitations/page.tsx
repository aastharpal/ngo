'use client';

import { useState } from 'react';
import { UserRole } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Mail, UserPlus, Send, RefreshCw, XCircle, CheckCircle2, Clock } from 'lucide-react';

interface Invitation {
  id: string;
  email: string;
  role: UserRole;
  status: 'PENDING' | 'ACCEPTED' | 'EXPIRED';
  sentAt: string;
  expiresAt: string;
}

const INITIAL_INVITATIONS: Invitation[] = [
  {
    id: 'inv-1',
    email: 'karan.singh@example.com',
    role: 'COORDINATOR',
    status: 'PENDING',
    sentAt: '2026-10-01',
    expiresAt: '2026-10-08',
  },
  {
    id: 'inv-2',
    email: 'priya.verma@example.com',
    role: 'VOLUNTEER',
    status: 'ACCEPTED',
    sentAt: '2026-09-25',
    expiresAt: '2026-10-02',
  },
  {
    id: 'inv-3',
    email: 'suresh.kumar@example.com',
    role: 'VOLUNTEER',
    status: 'EXPIRED',
    sentAt: '2026-09-10',
    expiresAt: '2026-09-17',
  },
];

export default function InvitationsPage() {
  const [invitations, setInvitations] = useState<Invitation[]>(INITIAL_INVITATIONS);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Form State
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('VOLUNTEER');

  // Handle Sending Invitation
  const handleSendInvite = (e: React.FormEvent) => {
    e.preventDefault();

    const today = new Date();
    const expiry = new Date();
    expiry.setDate(today.getDate() + 7);

    const newInvite: Invitation = {
      id: `inv-${Date.now()}`,
      email,
      role,
      status: 'PENDING',
      sentAt: today.toISOString().split('T')[0],
      expiresAt: expiry.toISOString().split('T')[0],
    };

    setInvitations([newInvite, ...invitations]);
    setIsDialogOpen(false);
    setEmail('');
    setRole('VOLUNTEER');
  };

  // Resend Invite Handler
  const handleResend = (id: string) => {
    const today = new Date();
    const expiry = new Date();
    expiry.setDate(today.getDate() + 7);

    setInvitations((prev) =>
      prev.map((inv) =>
        inv.id === id
          ? {
              ...inv,
              status: 'PENDING',
              sentAt: today.toISOString().split('T')[0],
              expiresAt: expiry.toISOString().split('T')[0],
            }
          : inv
      )
    );
  };

  // Revoke/Cancel Invite Handler
  const handleRevoke = (id: string) => {
    setInvitations((prev) => prev.filter((inv) => inv.id !== id));
  };

  const getStatusBadge = (status: Invitation['status']) => {
    switch (status) {
      case 'ACCEPTED':
        return (
          <Badge className="bg-green-100 text-green-800 border-green-200 flex items-center gap-1 w-fit">
            <CheckCircle2 className="h-3 w-3" /> Accepted
          </Badge>
        );
      case 'PENDING':
        return (
          <Badge className="bg-amber-100 text-amber-800 border-amber-200 flex items-center gap-1 w-fit">
            <Clock className="h-3 w-3" /> Pending
          </Badge>
        );
      case 'EXPIRED':
        return (
          <Badge className="bg-gray-100 text-gray-600 border-gray-200 flex items-center gap-1 w-fit">
            <XCircle className="h-3 w-3" /> Expired
          </Badge>
        );
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 flex items-center gap-2">
            <Mail className="h-7 w-7 text-blue-600" />
            Staff & Volunteer Invitations
          </h1>
          <p className="text-gray-500 text-sm mt-1">
            Invite coordinators and volunteers to join your NGO workspace with role-based access.
          </p>
        </div>
        <Button
          onClick={() => setIsDialogOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white gap-2 self-start sm:self-auto"
        >
          <UserPlus className="h-4 w-4" />
          Send Invitation
        </Button>
      </div>

      {/* Main Content Card */}
      <Card className="border-gray-200 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold">Sent Invitations</CardTitle>
          <CardDescription>
            Invitations remain valid for 7 days. Recipients will receive a magic link to complete registration.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border border-gray-200 overflow-hidden">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead className="font-semibold">Recipient Email</TableHead>
                  <TableHead className="font-semibold">Assigned Role</TableHead>
                  <TableHead className="font-semibold">Sent Date</TableHead>
                  <TableHead className="font-semibold">Expiry Date</TableHead>
                  <TableHead className="font-semibold">Status</TableHead>
                  <TableHead className="text-right font-semibold">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invitations.map((inv) => (
                  <TableRow key={inv.id} className="hover:bg-gray-50/50">
                    <TableCell className="font-medium text-gray-900">
                      {inv.email}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs font-semibold uppercase">
                        {inv.role.replace('_', ' ')}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-gray-600 font-mono">
                      {inv.sentAt}
                    </TableCell>
                    <TableCell className="text-xs text-gray-600 font-mono">
                      {inv.expiresAt}
                    </TableCell>
                    <TableCell>{getStatusBadge(inv.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        {inv.status === 'EXPIRED' && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 text-xs gap-1 text-blue-600 border-blue-200 hover:bg-blue-50"
                            onClick={() => handleResend(inv.id)}
                          >
                            <RefreshCw className="h-3.5 w-3.5" />
                            Resend
                          </Button>
                        )}
                        {inv.status === 'PENDING' && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 text-xs gap-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                            onClick={() => handleRevoke(inv.id)}
                          >
                            <XCircle className="h-3.5 w-3.5" />
                            Revoke
                          </Button>
                        )}
                        {inv.status === 'ACCEPTED' && (
                          <span className="text-xs text-gray-400 italic">Member active</span>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Invite Modal Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <Send className="h-5 w-5 text-blue-600" />
              Invite Team Member
            </DialogTitle>
            <DialogDescription className="text-sm text-gray-500">
              An invitation email with onboarding instructions will be sent immediately.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSendInvite} className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="invite-email" className="text-xs font-medium">Email Address</Label>
              <Input
                id="invite-email"
                type="email"
                required
                placeholder="colleague@example.org"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="invite-role" className="text-xs font-medium">Assign Role</Label>
              <select
                id="invite-role"
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
              >
                <option value="VOLUNTEER">Volunteer (Execute assigned tasks)</option>
                <option value="COORDINATOR">Coordinator (Manage projects & assign tasks)</option>
                <option value="NGO_ADMIN">NGO Admin (Full org administration)</option>
              </select>
            </div>

            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white gap-1.5">
                <Send className="h-3.5 w-3.5" />
                Send Invite
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}