'use client';

import { useState } from 'react';
import { MOCK_TASKS, MOCK_PROJECTS } from '@/lib/mock-data';
import { Task, TaskStatus, TaskPriority } from '@/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckSquare, Plus, Clock, User, CheckCircle2, PlayCircle } from 'lucide-react';

export default function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [projectId, setProjectId] = useState(MOCK_PROJECTS[0]?.id || 'prj-101');
  const [priority, setPriority] = useState<TaskPriority>('MEDIUM');
  const [assignedTo, setAssignedTo] = useState('Priya Verma');
  const [deadline, setDeadline] = useState('');

  // Handle Task Status Change
  const handleStatusChange = (taskId: string, newStatus: TaskStatus) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === taskId
          ? {
              ...task,
              status: newStatus,
              completedAt: newStatus === 'COMPLETED' ? new Date().toISOString() : undefined,
            }
          : task
      )
    );
  };

  // Handle New Task Creation
  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();

    const newTask: Task = {
      id: `tsk-${Date.now()}`,
      projectId,
      title,
      description,
      priority,
      deadline: deadline ? new Date(deadline).toISOString() : new Date().toISOString(),
      status: 'PENDING',
      assignedTo,
    };

    setTasks([newTask, ...tasks]);
    setIsDialogOpen(false);

    // Reset Form
    setTitle('');
    setDescription('');
    setDeadline('');
  };

  const getPriorityBadge = (p: TaskPriority) => {
    switch (p) {
      case 'HIGH':
        return <Badge className="bg-red-100 text-red-800 border-red-200">High</Badge>;
      case 'MEDIUM':
        return <Badge className="bg-amber-100 text-amber-800 border-amber-200">Medium</Badge>;
      case 'LOW':
        return <Badge className="bg-gray-100 text-gray-800 border-gray-200">Low</Badge>;
    }
  };

  const getStatusBadge = (s: TaskStatus) => {
    switch (s) {
      case 'COMPLETED':
        return <Badge className="bg-green-100 text-green-800 border-green-200 flex items-center gap-1"><CheckCircle2 className="h-3 w-3" /> Completed</Badge>;
      case 'IN_PROGRESS':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200 flex items-center gap-1"><PlayCircle className="h-3 w-3" /> In Progress</Badge>;
      case 'PENDING':
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200 flex items-center gap-1"><Clock className="h-3 w-3" /> Pending</Badge>;
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 flex items-center gap-2">
            <CheckSquare className="h-7 w-7 text-blue-600" />
            Task Management & Assignments
          </h1>
          <p className="text-gray-500 text-sm mt-1">
            Assign responsibilities to volunteers, track progress, and complete deliverables.
          </p>
        </div>
        <Button
          onClick={() => setIsDialogOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white gap-2 self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          Create Task
        </Button>
      </div>

      {/* Task Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tasks.map((task) => {
          const associatedProject = MOCK_PROJECTS.find((p) => p.id === task.projectId);

          return (
            <Card key={task.id} className="border-gray-200 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="text-xs font-semibold text-gray-500 truncate">
                    {associatedProject ? associatedProject.title : 'General Task'}
                  </span>
                  {getPriorityBadge(task.priority)}
                </div>
                <CardTitle className="text-base font-bold text-gray-900">
                  {task.title}
                </CardTitle>
                <CardDescription className="text-xs text-gray-500 line-clamp-2 mt-1">
                  {task.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-2 text-xs text-gray-600 py-2 border-t border-b border-gray-100 my-2">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Assigned To:</span>
                  <span className="font-semibold text-gray-800 flex items-center gap-1">
                    <User className="h-3.5 w-3.5 text-blue-600" />
                    {task.assignedTo || 'Unassigned'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Deadline:</span>
                  <span className="font-mono text-gray-700" suppressHydrationWarning>
                    {new Date(task.deadline).toLocaleDateString('en-US')}
                  </span>
                </div>
                <div className="flex items-center justify-between pt-1">
                  <span className="text-gray-400">Current Status:</span>
                  {getStatusBadge(task.status)}
                </div>
              </CardContent>

              {/* Status Actions */}
              <div className="p-4 pt-2 flex items-center justify-end gap-2">
                {task.status === 'PENDING' && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full text-xs h-8 text-blue-600 border-blue-200 hover:bg-blue-50"
                    onClick={() => handleStatusChange(task.id, 'IN_PROGRESS')}
                  >
                    Start Task
                  </Button>
                )}
                {task.status === 'IN_PROGRESS' && (
                  <Button
                    size="sm"
                    className="w-full text-xs h-8 bg-green-600 hover:bg-green-700 text-white"
                    onClick={() => handleStatusChange(task.id, 'COMPLETED')}
                  >
                    Mark Completed
                  </Button>
                )}
                {task.status === 'COMPLETED' && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="w-full text-xs h-8 text-gray-400 cursor-default"
                    disabled
                  >
                    Done ✓
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {/* Create Task Modal */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold text-gray-900">Create & Assign Task</DialogTitle>
            <DialogDescription className="text-sm text-gray-500">
              Add a new task deliverable and assign it to a team member or volunteer.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreateTask} className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="task-title" className="text-xs font-medium">Task Title</Label>
              <Input
                id="task-title"
                required
                placeholder="e.g., Distribute clean water kits"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="task-desc" className="text-xs font-medium">Description</Label>
              <Input
                id="task-desc"
                required
                placeholder="Details about what needs to be done"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="task-project" className="text-xs font-medium">Project</Label>
                <select
                  id="task-project"
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                  value={projectId}
                  onChange={(e) => setProjectId(e.target.value)}
                >
                  {MOCK_PROJECTS.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="task-priority" className="text-xs font-medium">Priority</Label>
                <select
                  id="task-priority"
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as TaskPriority)}
                >
                  <option value="LOW">Low</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="HIGH">High</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="task-assignee" className="text-xs font-medium">Assign To</Label>
                <Input
                  id="task-assignee"
                  required
                  placeholder="Volunteer Name"
                  value={assignedTo}
                  onChange={(e) => setAssignedTo(e.target.value)}
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="task-deadline" className="text-xs font-medium">Deadline</Label>
                <Input
                  id="task-deadline"
                  type="date"
                  required
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                />
              </div>
            </div>

            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white">
                Create Task
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}