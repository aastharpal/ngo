'use client';

import { useEffect, useState } from 'react';
import { UserRole } from '@/types';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [role, setRole] = useState<UserRole>('NGO_ADMIN');

  useEffect(() => {
    // Sync active role from login session
    const savedRole = localStorage.getItem('user_role') as UserRole;
    if (savedRole) {
      setRole(savedRole);
    }
  }, []);

  // Pass 'role' to your Navigation/Sidebar and Header components...
  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar & Header components rendering based on 'role' */}
      {children}
    </div>
  );
}